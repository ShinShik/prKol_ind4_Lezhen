﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAddDisk = new Button();
            btnRemoveDisk = new Button();
            btnRemoveSong = new Button();
            btnAddSong = new Button();
            btnSearchArtist = new Button();
            txtDiskName = new TextBox();
            label1 = new Label();
            label2 = new Label();
            txtSongName = new TextBox();
            listBoxDiscs = new ListBox();
            label3 = new Label();
            txtArtist = new TextBox();
            listBoxSongs = new ListBox();
            SuspendLayout();
            // 
            // btnAddDisk
            // 
            btnAddDisk.Location = new Point(15, 190);
            btnAddDisk.Name = "btnAddDisk";
            btnAddDisk.Size = new Size(123, 23);
            btnAddDisk.TabIndex = 0;
            btnAddDisk.Text = "Добавить диск";
            btnAddDisk.UseVisualStyleBackColor = true;
            btnAddDisk.Click += btnAddDisk_Click_1;
            // 
            // btnRemoveDisk
            // 
            btnRemoveDisk.Location = new Point(15, 219);
            btnRemoveDisk.Name = "btnRemoveDisk";
            btnRemoveDisk.Size = new Size(123, 23);
            btnRemoveDisk.TabIndex = 1;
            btnRemoveDisk.Text = "Удалить диск";
            btnRemoveDisk.UseVisualStyleBackColor = true;
            btnRemoveDisk.Click += btnRemoveDisk_Click_1;
            // 
            // btnRemoveSong
            // 
            btnRemoveSong.Location = new Point(15, 277);
            btnRemoveSong.Name = "btnRemoveSong";
            btnRemoveSong.Size = new Size(123, 23);
            btnRemoveSong.TabIndex = 3;
            btnRemoveSong.Text = "Удалить песню";
            btnRemoveSong.UseVisualStyleBackColor = true;
            btnRemoveSong.Click += btnRemoveSong_Click;
            // 
            // btnAddSong
            // 
            btnAddSong.Location = new Point(15, 248);
            btnAddSong.Name = "btnAddSong";
            btnAddSong.Size = new Size(123, 23);
            btnAddSong.TabIndex = 2;
            btnAddSong.Text = "Добавить песню";
            btnAddSong.UseVisualStyleBackColor = true;
            btnAddSong.Click += btnAddSong_Click_1;
            // 
            // btnSearchArtist
            // 
            btnSearchArtist.Location = new Point(15, 306);
            btnSearchArtist.Name = "btnSearchArtist";
            btnSearchArtist.Size = new Size(123, 23);
            btnSearchArtist.TabIndex = 5;
            btnSearchArtist.Text = "Найти артиста";
            btnSearchArtist.UseVisualStyleBackColor = true;
            btnSearchArtist.Click += btnSearchArtist_Click;
            // 
            // txtDiskName
            // 
            txtDiskName.Location = new Point(15, 68);
            txtDiskName.Name = "txtDiskName";
            txtDiskName.Size = new Size(100, 23);
            txtDiskName.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(15, 50);
            label1.Name = "label1";
            label1.Size = new Size(65, 15);
            label1.TabIndex = 8;
            label1.Text = "Имя диска";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(15, 96);
            label2.Name = "label2";
            label2.Size = new Size(67, 15);
            label2.TabIndex = 10;
            label2.Text = "Имя песни";
            // 
            // txtSongName
            // 
            txtSongName.Location = new Point(15, 114);
            txtSongName.Name = "txtSongName";
            txtSongName.Size = new Size(100, 23);
            txtSongName.TabIndex = 9;
            // 
            // listBoxDiscs
            // 
            listBoxDiscs.FormattingEnabled = true;
            listBoxDiscs.ItemHeight = 15;
            listBoxDiscs.Location = new Point(144, 50);
            listBoxDiscs.Name = "listBoxDiscs";
            listBoxDiscs.Size = new Size(356, 304);
            listBoxDiscs.TabIndex = 11;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(15, 143);
            label3.Name = "label3";
            label3.Size = new Size(76, 15);
            label3.TabIndex = 13;
            label3.Text = "Имя артиста";
            // 
            // txtArtist
            // 
            txtArtist.Location = new Point(15, 161);
            txtArtist.Name = "txtArtist";
            txtArtist.Size = new Size(100, 23);
            txtArtist.TabIndex = 12;
            // 
            // listBoxSongs
            // 
            listBoxSongs.FormattingEnabled = true;
            listBoxSongs.ItemHeight = 15;
            listBoxSongs.Location = new Point(506, 50);
            listBoxSongs.Name = "listBoxSongs";
            listBoxSongs.Size = new Size(287, 139);
            listBoxSongs.TabIndex = 14;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listBoxSongs);
            Controls.Add(label3);
            Controls.Add(txtArtist);
            Controls.Add(listBoxDiscs);
            Controls.Add(label2);
            Controls.Add(txtSongName);
            Controls.Add(label1);
            Controls.Add(txtDiskName);
            Controls.Add(btnSearchArtist);
            Controls.Add(btnRemoveSong);
            Controls.Add(btnAddSong);
            Controls.Add(btnRemoveDisk);
            Controls.Add(btnAddDisk);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAddDisk;
        private Button btnRemoveDisk;
        private Button btnRemoveSong;
        private Button btnAddSong;
        private Button btnSearchArtist;
        private TextBox txtDiskName;
        private Label label1;
        private Label label2;
        private TextBox txtSongName;
        private ListBox listBoxDiscs;
        private Label label3;
        private TextBox txtArtist;
        private ListBox listBoxSongs;
    }
}
