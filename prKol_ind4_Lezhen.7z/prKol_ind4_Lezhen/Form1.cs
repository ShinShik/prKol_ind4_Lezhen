using System;
using System.Collections;
using System.Security.Policy;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        Hashtable discs = new Hashtable();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAddDisk_Click_1(object sender, EventArgs e)
        {
            try
            {
                string discName = txtDiskName.Text;
                if (!String.IsNullOrWhiteSpace(discName))
                {
                    discs.Add(discName, new Hashtable());
                    UpdateListBox();
                }
            }
            catch
            {
                MessageBox.Show("���� � ����� ��������� ��� ����");
            }
        }

        private void btnRemoveDisk_Click_1(object sender, EventArgs e)
        {
            if (listBoxDiscs.SelectedItem != null)
            {
                string discName = listBoxDiscs.SelectedItem.ToString();
                discs.Remove(discName);
                UpdateListBox();
            }
            else
            {
                MessageBox.Show("�������� ���� ������� ������� �������");
            }
        }
        private void btnAddSong_Click_1(object sender, EventArgs e)
        {
            if (listBoxDiscs.SelectedItem != null)
            {
                string discName = listBoxDiscs.SelectedItem.ToString();
                Hashtable songs = (Hashtable)discs[discName];
                string artist = txtArtist.Text;
                string song = txtSongName.Text;
                if (!String.IsNullOrWhiteSpace(artist) && !String.IsNullOrWhiteSpace(song))
                {
                    try
                    {
                        songs.Add(artist, song);
                        UpdateListBox();
                    }
                    catch { }
                }
            }
            else
            {
                MessageBox.Show("�������� ���� �� ������� ����� ������� ������");
            }
        }
        private void UpdateListBox()
        {
            listBoxDiscs.Items.Clear();
            listBoxSongs.Items.Clear();

            foreach (DictionaryEntry disc in discs)
            {
                listBoxDiscs.Items.Add(disc.Key);
                Hashtable songs = (Hashtable)disc.Value;
                foreach (DictionaryEntry song in songs)
                {
                    listBoxSongs.Items.Add(song.Value);
                }
            }
        }

        private void btnSearchArtist_Click(object sender, EventArgs e)
        {
            string artist = txtArtist.Text;
            foreach (DictionaryEntry disc in discs)
            {
                Hashtable songs = (Hashtable)disc.Value;
                foreach (DictionaryEntry song in songs)
                {
                    if (song.Key.ToString() == artist)
                    {
                        MessageBox.Show(song.Value.ToString());
                    }
                }
            }
        }

        private void btnRemoveSong_Click(object sender, EventArgs e)
        {
            if (listBoxDiscs.SelectedItem != null)
            {
                string discName = listBoxDiscs.SelectedItem.ToString();
                string artist = txtArtist.Text;
                if (!String.IsNullOrWhiteSpace(artist))
                {
                    Hashtable songs = (Hashtable)discs[discName];
                    if (songs.Contains(artist))
                    {
                        songs.Remove(artist);
                        UpdateListBox();
                    }
                }
            }
            else
            {
                MessageBox.Show("�������� ���� � �������� ���� ������� �����");
            }
        }
    }
}
